export enum BikeStatus {
  LOST = "LOST",
  STOLEN = "STOLEN",
  FOUND = "FOUND",
  FOR_SALE_EXTERNAL = "FOR_SALE_EXTERNAL",
}

export interface User {
  id: string;
  email: string;
  createdAt: Date;
}

export interface Bike {
  id: string;
  brand?: string;
  model?: string;
  color?: string;
  serialNumber?: string;
  description?: string;
  status: BikeStatus;
  locationLat?: number;
  locationLng?: number;
  city?: string;
  createdAt: Date;
  updatedAt: Date;
  source?: string;
  sourceUrl?: string;
  phash?: string;
}

export interface Image {
  id: string;
  url: string;
  bikeId: string;
  createdAt: Date;
}

export interface Report {
  id: string;
  userId: string;
  bikeId: string;
  lostDate?: Date;
  place?: string;
  contact?: string;
  createdAt: Date;
}

export interface Find {
  id: string;
  userId: string;
  bikeId: string;
  note?: string;
  foundDate?: Date;
  createdAt: Date;
}