export interface ExternalListing {
  title: string;
  price?: number;
  city?: string;
  url: string;
  image?: string;
  extractedAt: Date;
}