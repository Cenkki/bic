#!/usr/bin/env node

/**
 * Cron job to fetch external listings from Tori.fi and other sources
 * This script should be run periodically to update external listings
 */

const { PrismaClient } = require("@prisma/client");

// Simple mock data for external listings
const mockExternalListings = [
  {
    title: "Miesten hybridipyörä, sininen, hyvä kunto",
    price: 350,
    city: "Helsinki",
    url: "https://example.com/listing/1",
    image: "/images/bike1.jpg",
    extractedAt: new Date("2023-06-15"),
  },
  {
    title: "Naisten kaupunkipyörä, Punainen, Kolmen vaihteinen",
    price: 200,
    city: "Espoo",
    url: "https://example.com/listing/2",
    image: "/images/bike2.jpg",
    extractedAt: new Date("2023-06-14"),
  },
  {
    title: "Lasten polkupyörä, 16 tuumaa, sininen ja valkoinen",
    price: 120,
    city: "Vantaa",
    url: "https://example.com/listing/3",
    image: "/images/bike3.jpg",
    extractedAt: new Date("2023-06-13"),
  },
];

// Simple bike status enum
const BikeStatus = {
  LOST: "LOST",
  STOLEN: "STOLEN",
  FOUND: "FOUND",
  FOR_SALE_EXTERNAL: "FOR_SALE_EXTERNAL",
};

// Simple function to extract bike info from title
function extractBikeInfo(title) {
  const lowerTitle = title.toLowerCase();
  
  // Simple brand detection
  const brands = ["trek", "giant", "specialized", "cannondale", "scott"];
  const brand = brands.find(b => lowerTitle.includes(b));
  
  // Simple color detection
  const colors = ["sininen", "punainen", "vihreä", "musta", "valkoinen", "harmaa", "keltainen"];
  const color = colors.find(c => lowerTitle.includes(c));
  
  // Simple model/feature detection
  const features = ["hybridipyörä", "kaupunkipyörä", "polkupyörä", "maastopyörä", "lastenpyörä"];
  const model = features.find(f => lowerTitle.includes(f));
  
  return {
    brand: brand ? brand.charAt(0).toUpperCase() + brand.slice(1) : undefined,
    model,
    color: color ? color.charAt(0).toUpperCase() + color.slice(1) : undefined,
  };
}

// Convert external listing to bike format
function externalListingToBike(listing) {
  const bikeInfo = extractBikeInfo(listing.title);
  
  return {
    id: `external-${listing.url.split('/').pop()}`,
    brand: bikeInfo.brand,
    model: bikeInfo.model,
    color: bikeInfo.color,
    status: BikeStatus.FOR_SALE_EXTERNAL,
    city: listing.city,
    source: "tori.fi",
    sourceUrl: listing.url,
    createdAt: listing.extractedAt,
    updatedAt: listing.extractedAt,
    image: listing.image,
    price: listing.price,
    serialNumber: undefined,
  };
}

// Fetch external listings (mock implementation)
async function fetchExternalListings() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  // Return mock data
  return [...mockExternalListings];
}

const prisma = new PrismaClient();

async function fetchForSaleListings() {
  console.log("Starting fetchForSale cron job...");
  
  try {
    // Fetch external listings
    console.log("Fetching external listings...");
    const listings = await fetchExternalListings();
    console.log(`Fetched ${listings.length} listings`);
    
    let newBikesCount = 0;
    let updatedBikesCount = 0;
    
    // Process each listing
    for (const listing of listings) {
      try {
        // Convert listing to bike format
        const convertedBike = externalListingToBike(listing);
        
        // Check if bike already exists
        const existingBike = await prisma.bike.findFirst({
          where: {
            AND: [
              { sourceUrl: convertedBike.sourceUrl },
              { status: BikeStatus.FOR_SALE_EXTERNAL }
            ]
          }
        });
        
        if (existingBike) {
          // Update existing bike
          await prisma.bike.update({
            where: { id: existingBike.id },
            data: {
              brand: convertedBike.brand,
              model: convertedBike.model,
              color: convertedBike.color,
              city: convertedBike.city,
              updatedAt: new Date(),
            }
          });
          updatedBikesCount++;
        } else {
          // Create new bike
          await prisma.bike.create({
            data: {
              brand: convertedBike.brand,
              model: convertedBike.model,
              color: convertedBike.color,
              status: BikeStatus.FOR_SALE_EXTERNAL,
              city: convertedBike.city,
              source: convertedBike.source,
              sourceUrl: convertedBike.sourceUrl,
              createdAt: convertedBike.createdAt,
              updatedAt: convertedBike.updatedAt,
            }
          });
          newBikesCount++;
        }
      } catch (error) {
        console.error(`Error processing listing ${listing.url}:`, error);
      }
    }
    
    console.log(`FetchForSale cron job completed. Added ${newBikesCount} new bikes, updated ${updatedBikesCount} bikes.`);
  } catch (error) {
    console.error("Error in fetchForSale cron job:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

// Run the cron job if this file is executed directly
if (require.main === module) {
  fetchForSaleListings().catch(console.error);
}

module.exports = fetchForSaleListings;