#!/usr/bin/env node

/**
 * Cron job to recompute matches for new bikes
 * This script should be run periodically to find new matches
 */

const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

// Calculate Hamming distance between two hashes
function hammingDistance(hash1, hash2) {
  if (hash1.length !== hash2.length) return -1;
  
  let distance = 0;
  for (let i = 0; i < hash1.length; i++) {
    if (hash1[i] !== hash2[i]) {
      distance++;
    }
  }
  return distance;
}

// Get opposite statuses for matching
function getOppositeStatuses(status) {
  switch (status) {
    case "LOST":
    case "STOLEN":
      return ["FOUND", "FOR_SALE_EXTERNAL"];
    case "FOUND":
    case "FOR_SALE_EXTERNAL":
      return ["LOST", "STOLEN"];
    default:
      return [];
  }
}

// Find matches based on serial number
async function findSerialNumberMatches(bike) {
  const matches = [];
  
  // Don't match against bikes with the same status
  const oppositeStatuses = getOppositeStatuses(bike.status);
  
  const matchingBikes = await prisma.bike.findMany({
    where: {
      AND: [
        { serialNumber: bike.serialNumber },
        { id: { not: bike.id } },
        { status: { in: oppositeStatuses } }
      ]
    }
  });

  for (const matchedBike of matchingBikes) {
    matches.push({
      id: `serial-${bike.id}-${matchedBike.id}`,
      bikeId: bike.id,
      matchedBikeId: matchedBike.id,
      confidence: 95, // High confidence for exact serial match
      matchType: "SERIAL_NUMBER",
      details: `Sarjanumero täsmää: ${bike.serialNumber}`
    });
  }

  return matches;
}

// Find matches based on pHash similarity
async function findPhashMatches(bike) {
  const matches = [];
  
  // Don't match against bikes with the same status
  const oppositeStatuses = getOppositeStatuses(bike.status);
  
  const potentialMatches = await prisma.bike.findMany({
    where: {
      AND: [
        { phash: { not: null } },
        { id: { not: bike.id } },
        { status: { in: oppositeStatuses } }
      ]
    }
  });

  for (const matchedBike of potentialMatches) {
    if (!matchedBike.phash) continue;
    
    const distance = hammingDistance(bike.phash, matchedBike.phash);
    if (distance === -1 || distance > 10) continue;
    
    // Confidence based on distance (0 distance = 100% confidence, 10 distance = 0% confidence)
    const confidence = Math.max(0, 100 - (distance * 10));
    
    if (confidence >= 50) { // Only include matches with at least 50% confidence
      matches.push({
        id: `phash-${bike.id}-${matchedBike.id}`,
        bikeId: bike.id,
        matchedBikeId: matchedBike.id,
        confidence,
        matchType: "PHASH",
        details: `Visuaalinen samankaltaisuus (etäisyys: ${distance})`
      });
    }
  }

  return matches;
}

// Find matches based on keywords and city
async function findKeywordMatches(bike) {
  const matches = [];
  
  if (!bike.brand && !bike.model) {
    return matches; // Can't match without brand or model
  }
  
  // Don't match against bikes with the same status
  const oppositeStatuses = getOppositeStatuses(bike.status);
  
  const potentialMatches = await prisma.bike.findMany({
    where: {
      AND: [
        { id: { not: bike.id } },
        { city: bike.city },
        { status: { in: oppositeStatuses } },
        {
          OR: [
            bike.brand ? { brand: { contains: bike.brand, mode: "insensitive" } } : {},
            bike.model ? { model: { contains: bike.model, mode: "insensitive" } } : {}
          ]
        }
      ]
    }
  });

  for (const matchedBike of potentialMatches) {
    // Calculate confidence based on matching fields
    let confidence = 0;
    const details = [];
    
    if (bike.brand && matchedBike.brand && 
        bike.brand.toLowerCase() === matchedBike.brand.toLowerCase()) {
      confidence += 40;
      details.push(`Merkki: ${bike.brand}`);
    }
    
    if (bike.model && matchedBike.model && 
        bike.model.toLowerCase() === matchedBike.model.toLowerCase()) {
      confidence += 40;
      details.push(`Malli: ${bike.model}`);
    }
    
    // Bonus for same city
    if (bike.city && matchedBike.city && 
        bike.city.toLowerCase() === matchedBike.city.toLowerCase()) {
      confidence += 20;
      details.push(`Kaupunki: ${bike.city}`);
    }
    
    if (confidence >= 50) { // Only include matches with at least 50% confidence
      matches.push({
        id: `keyword-${bike.id}-${matchedBike.id}`,
        bikeId: bike.id,
        matchedBikeId: matchedBike.id,
        confidence,
        matchType: "KEYWORDS",
        details: details.join(", ")
      });
    }
  }

  return matches;
}

/**
 * Find matches for a bike based on various criteria
 */
async function findMatchesForBike(bikeId) {
  try {
    const bike = await prisma.bike.findUnique({
      where: { id: bikeId }
    });

    if (!bike) {
      throw new Error("Bike not found");
    }

    const matches = [];

    // 1. Serial number matching
    if (bike.serialNumber) {
      const serialMatches = await findSerialNumberMatches(bike);
      matches.push(...serialMatches);
    }

    // 2. pHash similarity matching
    if (bike.phash) {
      const phashMatches = await findPhashMatches(bike);
      matches.push(...phashMatches);
    }

    // 3. Keyword + city matching
    const keywordMatches = await findKeywordMatches(bike);
    matches.push(...keywordMatches);

    // Remove duplicates and sort by confidence
    const uniqueMatches = Array.from(
      new Map(matches.map(match => [match.matchedBikeId, match])).values()
    );

    return uniqueMatches.sort((a, b) => b.confidence - a.confidence);
  } catch (error) {
    console.error("Error finding matches:", error);
    throw new Error("Failed to find matches");
  }
}

async function recomputeMatches() {
  console.log("Starting recomputeMatches cron job...");
  
  try {
    // Get bikes that haven't had matches computed recently (or ever)
    // For simplicity, we'll get bikes created in the last 24 hours
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    const recentBikes = await prisma.bike.findMany({
      where: {
        createdAt: {
          gte: oneDayAgo
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    });
    
    console.log(`Found ${recentBikes.length} recent bikes to process`);
    
    let totalMatchesFound = 0;
    
    // Process each bike
    for (const bike of recentBikes) {
      try {
        console.log(`Processing bike ${bike.id}...`);
        
        // Find matches for this bike
        const matches = await findMatchesForBike(bike.id);
        
        if (matches.length > 0) {
          console.log(`Found ${matches.length} matches for bike ${bike.id}`);
          totalMatchesFound += matches.length;
          
          // In a real implementation, you might want to:
          // 1. Store matches in a database table
          // 2. Send notifications to users
          // 3. Update a matches count on the bike record
          
          // For now, we'll just log the matches
          for (const match of matches) {
            console.log(`  Match: ${match.matchedBikeId} (confidence: ${match.confidence}%, type: ${match.matchType})`);
          }
        }
      } catch (error) {
        console.error(`Error processing bike ${bike.id}:`, error);
      }
    }
    
    console.log(`RecomputeMatches cron job completed. Found ${totalMatchesFound} total matches.`);
  } catch (error) {
    console.error("Error in recomputeMatches cron job:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

// Run the cron job if this file is executed directly
if (require.main === module) {
  recomputeMatches().catch(console.error);
}

module.exports = recomputeMatches;